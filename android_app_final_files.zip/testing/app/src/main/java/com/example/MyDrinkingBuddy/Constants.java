package com.example.MyDrinkingBuddy;

public class Constants {
    public static int drink = 0;
    static int image_select;
}
