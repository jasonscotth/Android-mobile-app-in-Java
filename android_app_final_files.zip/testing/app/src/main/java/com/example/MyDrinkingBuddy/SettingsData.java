package com.example.MyDrinkingBuddy;

public class SettingsData {
    static int weight = 197;
    static char gender = 'M';
}
